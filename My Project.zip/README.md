# GUIA1
This is a GUI from the C# Book I'm studying from.
